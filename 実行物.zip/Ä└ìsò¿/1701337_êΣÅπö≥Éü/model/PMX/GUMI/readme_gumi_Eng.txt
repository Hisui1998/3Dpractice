﻿GUMIβ V3 Ver. (2013/06/03)

Modeling, Setup: Mamama
(c)INTERNET Co.,Ltd.

This data is for pmx file of MikuMikuDance.
Please check all the available rules.
And please use this data on to have agreed.

About utilization of the model( character) will mention on character license (http://www.ssw.co.jp/products/vocal/character_guideline/) of INTERNET Co.,Ltd..

Edit:
OK, 

Distribute:
NO, Redistribution is prohibited.

PASS:2009~2013/0626
